def inserir_nova_questao(tema="CG"):

    if tema == "CG":
        print("a pergunta será armazenada no documento 'conhecimentos-gerais.txt' ")


inserir_nova_questao()