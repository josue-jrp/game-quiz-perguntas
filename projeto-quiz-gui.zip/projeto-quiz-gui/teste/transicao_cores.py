import tkinter as tk

def fade_widget(widget, target_color, steps=200, interval=1):
    """
    Faz uma transição simples de cor de fundo do widget até 'target_color'
    em um número de 'steps' passos, a cada 'interval' milissegundos.
    """
    current_color = widget.cget("bg")
    
    # Função interna para realizar a transição
    def change_color(step):
        # Calculando a nova cor (simulação de fade)
        r1, g1, b1 = widget.winfo_rgb(current_color)
        r2, g2, b2 = widget.winfo_rgb(target_color)
        
        # Cálculo da transição gradual
        r = r1 + (r2 - r1) * step // steps
        g = g1 + (g2 - g1) * step // steps
        b = b1 + (b2 - b1) * step // steps
        
        # Atualiza a cor de fundo do widget
        new_color = f"#{r:04x}{g:04x}{b:04x}"
        widget.config(bg=new_color)
        
        if step < steps:
            widget.after(interval, change_color, step + 1)

    change_color(0)

root = tk.Tk()

# Criando um botão que muda a cor de fundo ao ser clicado
button = tk.Button(root, text="Clique para Transição", width=20, height=3)
button.pack(pady=20)

button.config(command=lambda: fade_widget(root, "lightblue"))

root.mainloop()