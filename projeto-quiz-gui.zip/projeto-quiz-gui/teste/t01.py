from tkinter import *

def funcao(ti):

    def iniciar_tempo():
        nonlocal ti # é para poder usar o valor do argumento da função anterior

        if ti > 0:
            print(f"00:{ti}")
            texto.config(text=f"00:{ti:02d}")
            ti -= 1
            janela.after(1000, iniciar_tempo)
        else:
            print("caiu no else")
            texto.config(text="00:00")
            return

    iniciar_tempo()


tempo_inicial = 20

janela = Tk()
janela.geometry("500x500")
janela.title("teste cronometro")

frame = Frame(janela, width=400, height=400, bg="black")
frame.pack()
frame.propagate(False)

frame_tempo = Frame(frame, width=350, height=100)
frame_tempo.propagate(False)
frame_tempo.pack()

texto = Label(frame_tempo, text="00:00", bg="lightgreen")
texto.pack(pady=20)

botao = Button(frame_tempo, bg="lightblue", text="iniciar", command=lambda: funcao(tempo_inicial))
botao.pack()

janela.mainloop()