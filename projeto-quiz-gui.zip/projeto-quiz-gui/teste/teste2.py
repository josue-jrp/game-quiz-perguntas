from tkinter import *

def mudar_cor(widget, cor_alvo, intervalo=1):
    atual_cor = widget.cget("background")
    rgb_atual = widget.winfo_rgb(atual_cor)
    cor_desejada = widget.winfo_rgb(cor_alvo)

    def transicao(cor_botao, cor_desejada):
        r1 = cor_botao[0]
        g1 = cor_botao[1]
        b1 = cor_botao[2]

        r2 = cor_desejada[0]
        g2 = cor_desejada[1]
        b2 = cor_desejada[2]

        while r1 > r2 or g1 > g2 or b1 > b2:
            if r1 > b2:
                r1 = r1 - 10
                root.after(1, root.configure(bg=f"#{r1:04x}{g1:04x}{b1:04x}"))
            elif g1 > g2:
                g1 = g1 - 10
                root.after(1, root.configure(bg=f"#{r1:04x}{g1:04x}{b1:04x}"))
            elif b1 > b2:
                b1 = b1 - 10
                root.after(1, root.configure(bg=f"#{r1:04x}{g1:04x}{b1:04x}"))

    transicao(rgb_atual, cor_desejada)

root = Tk()
root.geometry("500x500")

botao = Button(text="clique para mudar para o tema escuro", command=lambda:mudar_cor(root, "black"))
botao.pack()

root.mainloop()